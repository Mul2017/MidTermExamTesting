package testCases;

import dao.StudentRegistrationDao;
import java.util.List;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import model.Semester;
import model.Student;


public class AllStudentsBySemester {
   
	 private StudentRegistrationDao studentRegistrationDao;

	public AllStudentsBySemester() {
	   }

	   @Before
	   public void setUp() {
	      this.studentRegistrationDao = new StudentRegistrationDao();
	   }

	   @Test
	   public void testGetAllStudentsBySemester() {
	      Semester semester = new Semester();
	      semester.setSemId("089");
	      List<Student> students = this.studentRegistrationDao.getAllStudentsBySemester(semester);
	      Assert.assertThat(students, CoreMatchers.is(CoreMatchers.not(CoreMatchers.nullValue())));
	      Assert.assertEquals((long)students.size(), 1L);
				   }
}
