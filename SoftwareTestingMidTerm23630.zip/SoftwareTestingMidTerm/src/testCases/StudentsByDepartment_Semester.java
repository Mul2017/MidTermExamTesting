package testCases;

import dao.StudentRegistrationDao;
import java.util.List;
import model.AcademicUnit;
import model.Semester;
import model.Student;
import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class StudentsByDepartment_Semester {

	private StudentRegistrationDao studentDao;

	public StudentsByDepartment_Semester() {
	}

	@Before
	public void setUp() {
		this.studentDao = new StudentRegistrationDao();
	}

	@Test
	public void testGetAllStudentsByDepartmentAndSemester() {
		AcademicUnit department = new AcademicUnit();
		department.setUnitCode("7");
		Semester semester = new Semester();
		semester.setSemId("3");
		List<Student> students = this.studentDao.getAllStudentsByDepartmentAndSemester(department, semester);
		Assert.assertThat(students, CoreMatchers.is(CoreMatchers.not(CoreMatchers.nullValue())));
	 }
}
