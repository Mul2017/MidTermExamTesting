package testCases;
import dao.CourseDao;
import java.util.List;
import model.Course;
import model.Student;
import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CoursesByStudent {
 
	 private CourseDao courseDao;

	   public CoursesByStudent() {
	   }

	   @Before
	   public void setUp() {
	      this.courseDao = new CourseDao();
	   }

	   @Test
	   public void testGetCoursesByStudent() {
	      Student student = new Student();
	      student.setRegNo("24652");
	      List<Course> courses = this.courseDao.getCoursesByStudent(student);
	      Assert.assertThat(courses, CoreMatchers.is(CoreMatchers.not(CoreMatchers.nullValue())));
	      Assert.assertEquals((long)courses.size(), 1L);
			   }
}
